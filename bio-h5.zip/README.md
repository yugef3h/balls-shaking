# 临时多页面模板更新 2018-09 by yuql

# 多页配置 vue.config.js => pages: {}

# vant rem 适配：
npm i -S amfe-flexible
npm i postcss-pxtorem --save-dev

# 打包性能分析 自定义
npm run report